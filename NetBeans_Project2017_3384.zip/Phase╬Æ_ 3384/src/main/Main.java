
package main;


import javax.swing.JApplet;
import view.*;

/**
 * @version 1.0
 * @author dxanthak - mountanton
 */
public class Main extends JApplet{
     public static void main(String args[]) throws Exception {
               
               GraphicUI game=new GraphicUI();
               game.setVisible(true);
                
         
    }
}
