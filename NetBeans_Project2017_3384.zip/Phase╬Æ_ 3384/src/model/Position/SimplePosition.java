
package model.Position;

import model.PlaceType.PlaceType;


public class SimplePosition extends Position{
   
    public SimplePosition(PlaceType placetype,int i) {
        super(placetype,i);
    }

}
