
package model.PlaceType;


public enum PlaceType {
    KNOSOS,FAISTOS,MALIA,ZAKROS
 }
