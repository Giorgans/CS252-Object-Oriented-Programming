
package model.Pawn;



public class Theseus extends Pawn{
    
    public Theseus(String player) {
        super(player);
    }
    
    @Override
    public String toString(){
        return "Θησέας";
    }
    
}
