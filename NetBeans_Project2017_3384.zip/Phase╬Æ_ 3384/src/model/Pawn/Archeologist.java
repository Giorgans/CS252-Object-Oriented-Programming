
package model.Pawn;

public class Archeologist extends Pawn {
    
    public Archeologist(String player) {
        super(player);
    }

    @Override
    public String toString() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}