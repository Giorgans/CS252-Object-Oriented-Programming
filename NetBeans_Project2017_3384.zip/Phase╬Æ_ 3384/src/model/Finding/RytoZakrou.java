/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.Finding;

/**
 *
 * @author george
 */
public class RytoZakrou extends RareFinding{

    public RytoZakrou() {
        super(25);
    }

    @Override
    public String toString() {
        return "Ανακάλυψες το Ρυτό της Ζάκρου!!!;\nΤο αγγείο βρέθηκε στο θησαυροφυλάκιο "
                + "του ανακτόρου της Ζάκρου\n μαζί με άλλα μοναδικά στο είδος τους τελετουργικά "
                + "σκεύη της νεοανακτορικής εποχής\n και αποτελεί χαρακτηριστικό παράδειγμα της "
                + "εφευρετικότητας\n και καλαισθησίας των Μινωιτών τεχνιτών.";
    }
    
}