/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.Finding;

/**
 *
 * @author george
 */
public class MinoasRing extends RareFinding{

    public MinoasRing() {
        super(25);
    }

    @Override
    public String toString() {
        return "Ανακάλυψες το Δαχτυλίδι του Μίνωα !!!;\nΤο «Δαχτυλίδι του Μίνωα», "
                + "ένα από τα μεγαλύτερα και σπανιότερα χρυσά σφραγιδικά στον κόσμο,\n "
                + "θεωρείται από τα καλύτερα δείγματα της κρητομυκηναϊκής σφραγιδικής.\n "
                + "Φέρει σύνθετη θρησκευτική παράσταση, που απεικονίζει μορφές οι οποίες εντάσσονται \n"
                + "στην κρητομυκηναϊκή θεματολογία, δεντρολατρία με καθιστή θεά, \nουρανό, γη και θάλασσα, "
                + "με ιερό πλοίο που έχει μορφή ιππόκαμπου.";
    }
    
}