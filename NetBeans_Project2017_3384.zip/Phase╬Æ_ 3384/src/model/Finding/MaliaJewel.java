/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.Finding;

/**
 *
 * @author george
 */
public class MaliaJewel extends RareFinding{

    public MaliaJewel() {
        super(25);
    }

    @Override
    public String toString() {
        return "Ανακάλυψες το Κόσμημα των Μαλίων!!!;\nΤο χρυσό κόσμημα των μελισσών "
                + "που φιλοξενείται στο Αρχαιολογικό Μουσείο Ηρακλείου,\n είναι διάσημο "
                + "αρχαιολογικό εύρημα από τον Χρυσόλακκο,\n τον ταφικό περίβολο της νεκρόπολης "
                + "των Μαλίων.";
    }
    
}